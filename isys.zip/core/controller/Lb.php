<?php


// 14 de Octubre del 2014
// Lb.php
// @brief el objeto legobox
// estoy inspirado : 14/oct/2014 - 0:55am - viendo : un millon de formas de morir en el oeste por 2da vez el dia de hoy
class Lb {

	public function Lb(){
	}

	public function start(){
		include "core/app/autoload.php";
		include "core/app/init.php";
	}

}

?>