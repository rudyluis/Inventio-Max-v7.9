<?php
Core::redir("./?view=home");
?>